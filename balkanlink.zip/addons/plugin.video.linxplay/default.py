import xbmc,xbmcvfs,xbmcaddon,xbmcgui,xbmcplugin,urllib.request,urllib.parse,urllib.error,os,re,sys,datetime,shutil,resolveurl,random


AddonTitle     = "LINXPLAY"
addon_id       = 'plugin.video.linxplay'
addon_fanart   = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id, 'fanart.jpg'))
icon           = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
baseurl        = 'https://log.greenb00k.org/uploads/menu.xml'

def open_url(url):      
    try:        
        req = urllib.request.Request(url)       
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0')  
        response = urllib.request.urlopen(req)  
        link=response.read().decode('utf-8')    
        response.close()        
        link=str(link).replace('\n','').replace('\r','').replace('<fanart></fanart>','<fanart>x</fanart>').replace('<thumbnail></thumbnail>','<thumbnail>x</thumbnail>')        
        print(link)     
        return link     
    except:quit()

def INDEX():
    url = baseurl
    link = open_url(url)
    match = re.compile('<item>(.+?)</item>', re.DOTALL).findall(link)

    for item in match:
        try:
            # Provera da li je item folder
            if '<folder>' in item:
                data = re.compile('<title>(.+?)</title>.+?<folder>(.+?)</folder>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>', re.DOTALL).findall(item)
                for name, folder_url, iconimage, fanart in data:
                    # Dodavanje foldera u navigaciju
                    if folder_url:
                        addDir(name, folder_url, 2, iconimage, fanart)
                    else:
                        xbmc.log("[LINXPLAY] URL za folder je prazan.", xbmc.LOGERROR)
            else:
                # Obrada običnih stavki
                data = re.compile('<title>(.+?)</title>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>', re.DOTALL).findall(item)
                for name, url, iconimage, fanart in data:
                    if url:
                        addLink(name, url, 3, iconimage, fanart)
                    else:
                        xbmc.log("[LINXPLAY] URL za link je prazan.", xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f"[LINXPLAY] Greška u INDEX funkciji: {str(e)}", xbmc.LOGERROR)


    
def GETPLAYLIST(name, url, iconimage, fanart):
    url2 = url
    link = open_url(url)
    match = re.compile('<item>(.+?)</item>', re.DOTALL).findall(link)
    
    for item in match:
        try:
            # Provera da li je item "Next Page"
            if '<folder>' in item and '[COLOR red][B]NEXT PAGE[/B][/COLOR]' in re.compile('<title>(.+?)</title>').findall(item)[0]:
                data = re.compile('<title>(.+?)</title>.+?<folder>(.+?)</folder>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>', re.DOTALL).findall(item)
                for name, folder_url, iconimage, fanart in data:
                    addDir(name, folder_url, 2, iconimage, fanart)  # Dodaj folder za sledeću stranu
            else:
                # Obrada običnih item-a
                data = re.compile('<title>(.+?)</title>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>', re.DOTALL).findall(item)
                for name, url, iconimage, fanart in data:
                    addLink(name, url, 3, iconimage, fanart)
        except Exception as e:
            xbmc.log(f"[LINXPLAY] Greška u GETPLAYLIST funkciji: {str(e)}", xbmc.LOGERROR)

            
def PLAYLINKS(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name)      
        liz.setArt({'icon':iconimage,'thumb':iconimage})
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def CHECKLINKS(name,url,iconimage):
        try:
                if resolveurl.HostedMediaFile(url).valid_url():
                        url = resolveurl.HostedMediaFile(url).resolve()
                        PLAYLINKS(name,url,iconimage)
                elif liveresolver.isValid(url)==True:
                        url=liveresolver.resolve(url)
                        PLAYLINKS(name,url,iconimage)
                else:PLAYLINKS(name,url,iconimage)
        except:
                notification(addtags('[COLOR red]LINXPLAY[/COLOR]'),'Stream Unavailable', '3000', icon)

def GETMULTI(name,url,iconimage):
    streamurl=[]
    streamname=[]
    streamicon=[]
    link=open_url(url)
    urls=re.compile('<title>'+re.escape(name)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
    iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(urls)[0]
    links=[]
    if '<link>' in urls:
                nlinks=re.compile('<link>(.+?)</link>').findall(urls)
                for nlink in nlinks:
                        links.append(nlink)
    i=1
    for sturl in links:
                sturl2=sturl
                if '(' in sturl:
                        sturl=sturl.split('(')[0]
                        caption=str(sturl2.split('(')[1].replace(')',''))
                        streamurl.append(sturl)
                        streamname.append(caption)
                else:
                        domain=sturl.split('/')[2].replace('www.','')                        
                        streamurl.append( sturl )
                        streamname.append('Link '+str(i)+ ' | ' +domain)
                i=i+1
    dialog = xbmcgui.Dialog()
    select = dialog.select(name,streamname)
    if select < 0:quit()
    else:
        url = streamurl[select]
        CHECKLINKS(name,url,iconimage)

def notification(title, message, ms, nart):
    xbmc.executebuiltin("XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")")

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param       

  

def addItem(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&iconimage="+urllib.parse.quote_plus(iconimage)+"&description="+urllib.parse.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name)
        liz.setArt({"icon":iconimage, "thumb":iconimage})
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def addDir(name,url,mode,iconimage,fanart):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&description="+str(description)+"&fanart="+urllib.parse.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name)
        liz.setArt({"thumb":iconimage})
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addLink(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)+"&description="+str(description)+"&iconimage="+urllib.parse.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name)
        liz.setArt({"icon":iconimage, "thumb":iconimage})

        liz.setProperty('fanart_image', fanart)
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
          
def resolve(name,url):
    if '.m3u8' in url or '.mp4' in url:
        xbmc.Player().play(url, xbmcgui.ListItem(name))

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None; fanart=None; description=None
try: site=urllib.parse.unquote_plus(params["site"])
except: pass
try: url=urllib.parse.unquote_plus(params["url"])
except: pass
try: name=urllib.parse.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.parse.unquote_plus(params["iconimage"])
except: pass
try: fanart=urllib.parse.unquote_plus(params["fanart"])
except: pass
try: description=urllib.parse.unquote_plus(["description"])
except: pass

if mode==None or url==None or len(url)<1:INDEX()
elif mode==2: GETPLAYLIST(name,url,iconimage,fanart)
elif mode==3: CHECKLINKS(name,url,iconimage)
elif mode==4: GETMULTI(name,url,iconimage)

xbmcplugin.endOfDirectory(int(sys.argv[1]))