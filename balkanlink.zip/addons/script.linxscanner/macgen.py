import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os,sys
import random
import xbmcvfs

HOME = xbmcvfs.translatePath('special://home/')
dirr = os.path.join(HOME, 'addons/script.linxscanner/combo/')

yeninesil = (
    "00:1A:79:",
)

feyzo = """
       MAC GENERATOR BY LINX
"""

print(feyzo)

# Allow the user to select options
selected_indices = xbmcgui.Dialog().multiselect("Izaberite opcije", yeninesil)

# Filter the selected options based on user selection
selected_options = [yeninesil[i] for i in selected_indices]

# Proceed with the selected options
dosya = xbmcgui.Dialog().input("Upiisite Ime Combo fajla", type=xbmcgui.INPUT_ALPHANUM)

karisik = xbmcgui.Dialog().yesno("Izmesani combo", "Zelite li napraviti izmesani combo?")

nesil = None
if not karisik:
    nesil = xbmcgui.Dialog().select("Izaberite Mac tip", selected_options)

adet_str = xbmcgui.Dialog().input("Upiisite broj kombi", type=xbmcgui.INPUT_NUMERIC)

DosyaA = os.path.join(dirr, f"{dosya}@LINXMAC.txt")

def kaydet(mac):
    with open(DosyaA, 'a+') as dosya:
        dosya.write(mac + "\n")

i = 0
while True:
    genmac = "%02x:%02x:%02x"% (random.randint(0, 256), random.randint(0, 256), random.randint(0, 256))
    genmac = genmac.replace('100','10')

    if karisik:
        for mac_prefix in selected_options:
            genmac = "%02x:%02x:%02x"% (random.randint(0, 256), random.randint(0, 256), random.randint(0, 256))
            genmac = genmac.replace('100','10')
            print(mac_prefix + genmac)
            kaydet(mac_prefix + genmac)
    else:
        print(selected_options[nesil - 1] + genmac)
        kaydet(selected_options[nesil - 1] + genmac)

    i += 1
    if str(i) == adet_str:
        break

print("\n\nGeneriranje je gotovo\n\n")
