# combo.py
# -*- coding: utf-8 -*-

import os
import re
import sys
import xbmc
import xbmcgui
import xbmcvfs
import requests

def main():
    PUBLIC_COMBO_URL = "https://log.greenb00k.org/combo/"
    UPLOAD_PHP_URL = "https://log.greenb00k.org/upload.php"
    public_txt_items = []
    
    
    try:
        r = requests.get(PUBLIC_COMBO_URL, timeout=10)
        if r.status_code == 200:
            pattern = r'href="([^"]+\.txt)"'
            links = re.findall(pattern, r.text, flags=re.IGNORECASE)

            for link in links:
                link = link.strip()
                full_url = (
                    PUBLIC_COMBO_URL.rstrip("/") + "/" + link
                    if not link.lower().startswith("http") else link
                )
                filename = os.path.basename(link)
                public_txt_items.append({"type": "public_file", "title": filename, "url": full_url})

            
            unique_dict = {item["title"]: item for item in public_txt_items}
            public_txt_items = sorted(unique_dict.values(), key=lambda x: x["title"].lower())

        else:
            xbmc.log(f"[combo.py] PUBLIC folder - HTTP status: {r.status_code}", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"[combo.py] Error retrieving the PUBLIC folder: {e}", xbmc.LOGERROR)

    
    local_txt_items = []
    HOME = xbmcvfs.translatePath('special://home/')
    combo_path = os.path.join(HOME, 'addons', 'script.linxscanner', 'combo')

    if os.path.exists(combo_path):
        txt_files = sorted(f for f in os.listdir(combo_path) if f.lower().endswith('.txt'))
        for f in txt_files:
            local_txt_items.append({"type": "local_file", "title": f, "path": os.path.join(combo_path, f)})
    else:
        xbmc.log(f"[combo.py] Local folder does not exist: {combo_path}", xbmc.LOGERROR)

    
    full_items = [{"type": "label", "title": "[COLOR red][B]PUBLIC COMBO[/B][/COLOR]"}]
    full_items.extend(public_txt_items or [{"type": "label", "title": "(No available PUBLIC .txt files.)"}])
    full_items.append({"type": "label", "title": "[COLOR limegreen][B]LOCAL COMBO[/B][/COLOR]"})
    full_items.extend(local_txt_items or [{"type": "label", "title": "(No available LOCAL .txt files.)"}])

    select_list = [item["title"] for item in full_items]

    
    choice = xbmcgui.Dialog().select("COMBO - select an item.", select_list)
    if choice == -1:
        xbmc.log("[combo.py] The user closed the dialog.", xbmc.LOGINFO)
        return

    selected_item = full_items[choice]

    
    if selected_item["type"] == "label":
        xbmcgui.Dialog().ok("Info", f"You selected: {selected_item['title']}\n(This is not a .txt file)")
        return
    elif selected_item["type"] == "public_file":
        chosen_url = selected_item["url"]
        file_name = selected_item["title"]
        if xbmcgui.Dialog().yesno("Download .txt", f"Do you want to download '{file_name}' to the local combo folder?"):
            try:
                r = requests.get(chosen_url, timeout=10)
                if r.status_code == 200:
                    local_path = os.path.join(combo_path, file_name)
                    with open(local_path, 'wb') as f:
                        f.write(r.content)
                    xbmcgui.Dialog().ok("Success", f"File '{file_name}' saved to:\n{local_path}")
                else:
                    xbmcgui.Dialog().ok("Error", f"Download failed (HTTP {r.status_code}).")
            except Exception as e:
                xbmcgui.Dialog().ok("Error", f"Download failed:\n{str(e)}")
        else:
            xbmc.log(f"[combo.py] Download canceled: {file_name}", xbmc.LOGINFO)
    elif selected_item["type"] == "local_file":
        chosen_path = selected_item["path"]
        file_name = selected_item["title"]
        actions = ["Upload to server", "Delete file from local folder"]
        action_choice = xbmcgui.Dialog().select(f"Options for '{file_name}'", actions)

        if action_choice == -1:
            xbmc.log("[combo.py] User closed options dialog", xbmc.LOGINFO)
        elif action_choice == 0:
            upload_file(chosen_path, file_name, UPLOAD_PHP_URL)
        elif action_choice == 1:
            if xbmcgui.Dialog().yesno("Delete file", f"Are you sure you want to delete '{file_name}'?"):
                try:
                    os.remove(chosen_path)
                    xbmcgui.Dialog().notification("Info", f"Deleted '{file_name}' from the local folder.")
                except Exception as e:
                    xbmcgui.Dialog().ok("Error during deletion", str(e))
            else:
                xbmc.log(f"[combo.py] File deletion canceled: {file_name}", xbmc.LOGINFO)

def upload_file(local_path, file_name, upload_url):
    if not os.path.exists(local_path):
        xbmcgui.Dialog().ok("Error", f"File does not exist:\n{local_path}")
        return

    try:
        with open(local_path, "rb") as f:
            files = {"file": (file_name, f, "text/plain")}
            r = requests.post(upload_url, files=files, timeout=10)
            if r.status_code == 200:
                xbmcgui.Dialog().ok("Upload result", f"Server response:\n{r.text}")
            else:
                xbmcgui.Dialog().ok("Upload error", f"HTTP {r.status_code}\nResponse:\n{r.text}")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Upload failed:\n{str(e)}")

if __name__ == '__main__':
    main()
