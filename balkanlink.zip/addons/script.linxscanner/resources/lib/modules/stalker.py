import os
import sys
import json
import glob
import sqlite3
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
from xbmcvfs import translatePath, delete


HOME = xbmcvfs.translatePath('special://home/')
addon_path = os.path.join(HOME, 'addons/script.linxscanner/')
hits_path = os.path.join(addon_path, 'Hits')
pvr_client_id = 'pvr.stalker'


userdata_path = translatePath("special://userdata/addon_data/pvr.stalker")
settings_file = os.path.join(userdata_path, "instance-settings-1.xml")


if not xbmc.getCondVisibility('System.HasAddon({})'.format(pvr_client_id)):
    xbmc.executebuiltin('InstallAddon({})'.format(pvr_client_id))


def disable_addon(addon_id):
    request = {
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": False},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(request))


def enable_addon(addon_id):
    request = {
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": True},
        "id": 1
    }
    xbmc.executeJSONRPC(json.dumps(request))


class PVRClient:
    @staticmethod
    def clear_pvr_data():
        
        db_files = glob.glob(translatePath('special://database/TV*.db'))
        for db_file in db_files:
            try:
                conn = sqlite3.connect(db_file)
                cursor = conn.cursor()
                tables = ["channels", "timers", "clients", "channelgroups", "map_channelgroups_channels"]
                for table in tables:
                    cursor.execute(f"DELETE FROM {table}")
                conn.commit()
                conn.close()
                xbmc.log(f"PVR database cleared: {db_file}", level=xbmc.LOGINFO)
            except sqlite3.Error as e:
                xbmc.log(f"Error clearing database {db_file}: {str(e)}", level=xbmc.LOGERROR)

        
        if os.path.exists(userdata_path):
            for filename in os.listdir(userdata_path):
                file_path = os.path.join(userdata_path, filename)
                if os.path.isfile(file_path):
                    delete(file_path)
                    xbmc.log(f"PVR file deleted: {file_path}", level=xbmc.LOGINFO)


def generate_xml(mac, server):
    return f"""<settings version=\"2\">
    <setting id=\"kodi_addon_instance_name\" default=\"true\" />
    <setting id=\"kodi_addon_instance_enabled\" default=\"true\">true</setting>
    <setting id=\"mac\">{mac}</setting>
    <setting id=\"server\">{server}/c/</setting>
    <setting id=\"time_zone\" default=\"true\">Europe/Kiev</setting>
    <setting id=\"connection_timeout\" default=\"true\">5</setting>
    <setting id=\"login\" default=\"true\" />
    <setting id=\"password\" default=\"true\" />
    <setting id=\"guide_preference\" default=\"true\">0</setting>
    <setting id=\"guide_cache\" default=\"true\">true</setting>
    <setting id=\"guide_cache_hours\" default=\"true\">24</setting>
    <setting id=\"epg_timeShift\" default=\"true\">0</setting>
    <setting id=\"xmltv_scope\" default=\"true\">0</setting>
    <setting id=\"xmltv_url\" default=\"true\" />
    <setting id=\"xmltv_path\" default=\"true\" />
    <setting id=\"token\" default=\"true\" />
    <setting id=\"serial_number\" default=\"true\" />
    <setting id=\"device_id\" default=\"true\" />
    <setting id=\"device_id2\" default=\"true\" />
    <setting id=\"signature\" default=\"true\" />
</settings>"""


def show_names():
    if not os.path.exists(hits_path):
        xbmcgui.Dialog().notification("Error", "The 'Hits' directory does not exist!", xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    names = []
    data = {}

    
    for filename in os.listdir(hits_path):
        if filename.endswith(".txt"):
            file_path = os.path.join(hits_path, filename)
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.split(";")
                    if len(parts) == 3:
                        name, url, mac = parts
                        display_name = f"{filename}: {name}"
                        names.append(display_name)
                        data[display_name] = (url, mac)

    if not names:
        xbmcgui.Dialog().notification("Error", "No available names in the files!", xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    
    dialog = xbmcgui.Dialog()
    selected = dialog.select("Select a name", names)

    if selected == -1:
        return  

    selected_name = names[selected]
    url, mac = data[selected_name]

    
    if dialog.yesno("Generate Settings", f"Do you want to generate settings for: {selected_name}?"):
        try:
            
            disable_addon(pvr_client_id)

            
            PVRClient.clear_pvr_data()

           
            xml_content = generate_xml(mac, url)
            if not os.path.exists(userdata_path):
                os.makedirs(userdata_path)
            with open(settings_file, "w", encoding="utf-8") as xml_file:
                xml_file.write(xml_content)

            xbmcgui.Dialog().notification("Settings Generated", f"Settings for {selected_name} have been generated.", xbmcgui.NOTIFICATION_INFO, 5000)

            
            enable_addon(pvr_client_id)
        except Exception as e:
            xbmc.log(f"Error generating XML: {str(e)}", level=xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Error", "Something went wrong!", xbmcgui.NOTIFICATION_ERROR, 5000)


show_names()
