import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs,os,sys
import os
import csv
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import requests
from resources.lib.modules import control
from datetime import datetime
from resources.lib.modules import TextViewer, pastebin

dp = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()
addonInfo = xbmcaddon.Addon().getAddonInfo
HOME = xbmcvfs.translatePath('special://home/')
hits2 = os.path.join(HOME, 'addons/plugin.video.bluethunder/resources/')
AddonTitle = "Linx Scanner"
AddonID = 'script.linxscanner'

def generate_xml_from_csv(selectLog, outputFilePath):
    xml_content = '<?xml version="1.0" encoding="UTF-8"?>\n<settings>\n'

    try:
        # Open the CSV file and read its contents
        with open(selectLog, mode='r', newline='', encoding='utf-8') as file:
            reader = csv.DictReader(file, delimiter=';')

            for index, row in enumerate(reader, start=1):
                name = row.get('Name', '')
                url = row.get('URL', '')
                mac = row.get('MAC', '')

                # Create XML content for each entry
                xml_content += f'  <category label="{name}">\n'
                xml_content += f'    <setting id="portal_name_{index}" type="text" label="Name" default="{name}" />\n'
                xml_content += f'    <setting id="portal_url_{index}" type="text" label="URL" default="{url}" visible="eq(-1,false)" />\n'
                xml_content += f'    <setting label="Use Custom MAC" type="bool" id="custom_mac_{index}" default="true"/>\n'
                xml_content += f'    <setting id="portal_mac_{index}" type="text" label="MAC" default="{mac}" visible="eq(-1,false)" />\n'
                xml_content += f'    <setting label="Send Serial" type="bool" id="send_serial_{index}" default="false"/>\n'
                xml_content += f'    <setting label="Custom Serial" type="bool" id="custom_serial_{index}" default="false" visible="eq(-1,true)"/>\n'
                xml_content += '    <setting type="sep"/>\n'
                xml_content += f'    <setting label="Serial Number" type="text" id="serial_number_{index}" default="" visible="eq(-2,true) + eq(-3,true)"/>\n'
                xml_content += f'    <setting label="Device ID 1" type="text" id="device_id_{index}" default="" visible="eq(-3,true) + eq(-4,true)"/>\n'
                xml_content += f'    <setting label="Device ID 2" type="text" id="device_id2_{index}" default="" visible="eq(-4,true) + eq(-5,true)"/>\n'
                xml_content += f'    <setting label="Signature" type="text" id="signature_{index}" default="" visible="eq(-5,true) + eq(-6,true)"/>\n'
                xml_content += '  </category>\n'

        xml_content += '</settings>'

        # Write the XML content to a file
        with open(outputFilePath, mode='w', encoding='utf-8') as file:
            file.write(xml_content)
        print(f"XML file written successfully to {outputFilePath}")

    except Exception as e:
        print(f"An error occurred while generating the XML: {e}")

def open_Settings():
    xbmcaddon.Addon(id=AddonID).openSettings()

def logView():
    modes = ['View your lists', 'Download/Upload PUBLIC', 'Upload LIST to PVR STALKER' , 'Upload LIST to BLUETHUNDER', 'Upload LIST to PASTEBIN']
    logPaths = []
    logNames = []
    
    # Display a dialog for mode selection
    select = control.selectDialog(modes)
    
    try:
        if select == -1:
            raise Exception("No mode selected.")
        
        if select == 1:
            # Directly run the script for option 3
            xbmc.executebuiltin('Runscript("special://home/addons/script.linxscanner/resources/lib/modules/lists.py")')
            return
        if select == 2:
            # Directly run the script for option 3
            xbmc.executebuiltin('Runscript("special://home/addons/script.linxscanner/resources/lib/modules/stalker.py")')
            return
        
        # Proceed with other options only if select is not 3
        translatePath = xbmcvfs.translatePath if hasattr(xbmcvfs, 'translatePath') else xbmc.translatePath
        hits1 = translatePath('special://home/addons/script.linxscanner/Hits/')
        
        # Populate logNames and logPaths lists
        for filename in os.listdir(hits1):
            if filename.endswith('.txt'):
                file_path = os.path.join(hits1, filename)
                if os.path.isfile(file_path):
                    logNames.append(filename)
                    logPaths.append(file_path)
        
        if not logPaths:
            raise Exception("No log files found.")
        
        selectLog = control.selectDialog(logNames)
        if selectLog == -1:
            raise Exception("No log file selected or selection was canceled.")
        
        selectedLog = logPaths[selectLog]

        if select == 0:
            TextViewer.text_view(selectedLog)
        elif select == 4:
            xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
            with open(selectedLog, 'rb') as f:
                text = f.read().decode('UTF-8')
            upload_Link = pastebin.api().paste(text)
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            if upload_Link and "Error" not in upload_Link:
                label = f"Log Link: [COLOR skyblue][B]{upload_Link}[/B][/COLOR]"
                dialog.ok(AddonTitle, "Log Uploaded to Pastebin\n" + label)
            else:
                dialog.ok(AddonTitle, "Cannot Upload Log to Pastebin\nReason: " + upload_Link)
        elif select == 3:
            generate_xml_from_csv(selectedLog, os.path.join(hits2, 'settings.xml'))
    except Exception as e:
        print(f"An error occurred: {e}")
        dialog.ok(AddonTitle, "An error occurred: " + str(e))


##############################    END    #########################################