import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os
import xbmcvfs
import requests
import zipfile
import shutil

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
HOME_DIR = xbmcvfs.translatePath('special://home')
ADDON_DATA = xbmcvfs.translatePath('special://home/userdata/addon_data/{}'.format(ADDON_ID))

# Create addon data folder if it doesn't exist
if not os.path.exists(ADDON_DATA):
    os.makedirs(ADDON_DATA)

def main_menu():
    """
    Display the main menu for the wizard.
    """
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),
                                url="plugin://plugin.program.wiz?mode=install_build",
                                listitem=xbmcgui.ListItem("Install Build"),
                                isFolder=True)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),
                                url="plugin://plugin.program.wiz?mode=clear_cache",
                                listitem=xbmcgui.ListItem("Clear Cache"),
                                isFolder=False)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),
                                url="plugin://plugin.program.wiz?mode=backup",
                                listitem=xbmcgui.ListItem("Backup Settings"),
                                isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def install_build(build_url):
    """
    Download and install a Kodi build from a zip URL.
    """
    try:
        dialog = xbmcgui.DialogProgress()
        dialog.create("Installing Build", "Downloading...")
        zip_path = os.path.join(HOME_DIR, 'build.zip')
        with open(zip_path, 'wb') as f:
            response = requests.get(build_url, stream=True)
            total_length = response.headers.get('content-length')
            if total_length is None:
                f.write(response.content)
            else:
                for chunk in response.iter_content(chunk_size=4096):
                    if chunk:
                        f.write(chunk)
        dialog.update(50, "Extracting Build...")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(HOME_DIR)
        os.remove(zip_path)
        dialog.update(100, "Build Installed!")
        xbmc.executebuiltin("Notification(Build Installed, Restart Kodi to apply changes)")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))

def clear_cache():
    """
    Clear Kodi's cache files.
    """
    cache_dirs = [
        xbmcvfs.translatePath('special://temp'),
        xbmcvfs.translatePath('special://home/cache'),
    ]
    for cache_dir in cache_dirs:
        if os.path.exists(cache_dir):
            for file in os.listdir(cache_dir):
                file_path = os.path.join(cache_dir, file)
                if os.path.isfile(file_path):
                    os.remove(file_path)
    xbmcgui.Dialog().ok("Success", "Cache cleared successfully!")

def backup_settings():
    """
    Backup user settings to a zip file.
    """
    try:
        backup_path = xbmcgui.Dialog().browse(0, 'Select Backup Location', 'files')
        backup_zip = os.path.join(backup_path, 'kodi_backup.zip')
        with zipfile.ZipFile(backup_zip, 'w') as zipf:
            for root, dirs, files in os.walk(HOME_DIR):
                for file in files:
                    zipf.write(os.path.join(root, file))
        xbmcgui.Dialog().ok("Success", f"Backup saved to {backup_zip}")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))

def route_action():
    """
    Route the selected action based on the mode parameter.
    """
    params = dict(arg.split('=') for arg in sys.argv[2][1:].split('&') if arg)
    mode = params.get('mode')
    if mode == "install_build":
        build_url = "https://log.greenb00k.org/jetin/Kodi.zip"
        if build_url:
            install_build(build_url)
    elif mode == "clear_cache":
        clear_cache()
    elif mode == "backup":
        backup_settings()
    else:
        main_menu()

if __name__ == "__main__":
    route_action()
