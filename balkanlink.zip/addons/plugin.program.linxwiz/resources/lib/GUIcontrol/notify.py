import xbmcgui
import xbmcaddon
from urllib.request import Request, urlopen
from uservar import notify_url


def get_notify() -> list:
    """
    Fetches notification data from the notify_url.
    Parses and returns the notification version and message.
    """
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0'}
    try:
        req = Request(notify_url, headers=headers)
        response = urlopen(req).read().decode('utf-8')
        split_response = response.split('|||')

        if len(split_response) != 2:
            raise ValueError("Unexpected response format")

        notify_version = int(split_response[0])
        message = split_response[1]
    except Exception as e:
        notify_version = 0
        message = f"Error retrieving notifications: {str(e)}"
    
    return [notify_version, message]


def notification(message: str) -> None:
    """
    Displays a notification message in an XBMC GUI window.
    """
    class Notify(xbmcgui.WindowXMLDialog):
        KEY_NAV_BACK = 92
        TEXTBOX = 300
        CLOSEBUTTON = 302

        def onInit(self):
            try:
                textbox = self.getControl(self.TEXTBOX)  # Get the control with ID=300
                if textbox:
                    textbox.setText(message)  # Set the text to the message
                else:
                    xbmcgui.Dialog().notification("Error", "Textbox not found")
            except Exception as e:
                xbmcgui.Dialog().notification("Error", f"Failed to set text: {str(e)}")

        def onAction(self, action):
            if action.getId() == self.KEY_NAV_BACK:
                self.close()

        def onClick(self, controlId):
            if controlId == self.CLOSEBUTTON:
                self.close()

    try:
        addon_path = xbmcaddon.Addon().getAddonInfo('path')
        d = Notify('notify.xml', addon_path, 'Default', '720p')
        d.doModal()
    except Exception as e:
        xbmcgui.Dialog().notification("Error", f"Failed to display notification: {str(e)}")
    finally:
        del d
