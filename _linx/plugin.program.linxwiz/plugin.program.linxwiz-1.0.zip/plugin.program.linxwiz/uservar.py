'''#####-----Build File-----#####'''
buildfile = 'https://github.com/addoncod/balkanlink/raw/refs/heads/main/builds.json'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/addoncod/balkanlink/refs/heads/main/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
