# plugin.program.linxwiz
Simple Wizard for Kodi
