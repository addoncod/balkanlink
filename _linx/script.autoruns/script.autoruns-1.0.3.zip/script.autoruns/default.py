# -*- coding: utf-8 -*-

""" Autoruns
    2013-2015 fightnight
    2022-2024 bittor7x0"""

import sys

from resources.lib.run_addon import run

if __name__ == "__main__":
    run(sys.argv)
