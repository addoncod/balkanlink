import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs,os,sys
import urllib
import re
import time
import requests
from resources.lib.modules import control, tools
from resources.lib.modules.backtothefuture import unicode, PY2
from resources.lib.modules import maintenance
import json

if PY2:
    quote_plus = urllib.quote_plus
    translatePath = xbmc.translatePath
else:
    quote_plus = urllib.parse.quote_plus
    translatePath = xbmcvfs.translatePath

AddonID ='script.linxscanner'
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
selfAddon    = xbmcaddon.Addon(id=AddonID)
backupfull   =  control.setting('backup_database')
backupaddons =  control.setting('backup_addon_data')
backupzip    =  control.setting("remote_backup")
USB          =  translatePath(os.path.join(backupzip))

# ICONS FANARTS
ADDON_FANART  = control.addonFanart()
ADDON_ICON    = control.addonIcon()

# DIRECTORIES
backupdir        =  translatePath(os.path.join('special://home/backupdir',''))
packagesdir      =  translatePath(os.path.join('special://home/addons/packages',''))
USERDATA         =  translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA       =  translatePath(os.path.join(USERDATA,'addon_data'))
HOME             =  translatePath('special://home/')
HOME_ADDONS      =  translatePath('special://home/addons')
backup_zip       =  translatePath(os.path.join(backupdir,'backup_addon_data.zip'))
STOPFLAG_PATH = translatePath(os.path.join('special://home/addons/script.linxscanner','.stopflag'))

# DIALOGS
dialog = xbmcgui.Dialog()
progressDialog = xbmcgui.DialogProgress()

AddonTitle = "Linx Scanner"
def SETTINGS():
    xbmcaddon.Addon(id=AddonID).openSettings()
# ######################### CATEGORIES ################################
def CATEGORIES():
    CreateDir('[COLOR white][B]IPTV SCANER [/B][/COLOR][COLOR green](START)[/COLOR]','ur','scan_on', ADDON_ICON, ADDON_FANART, '', isFolder=False)
    CreateDir('[COLOR white][B]IPTV SCANER [/B][/COLOR][COLOR red](KILL BOTS)[/COLOR]','ur','scan_off', ADDON_ICON, ADDON_FANART, '', isFolder=False)
    CreateDir('[COLOR white][B]MAC GENERATOR[/B][/COLOR]','ur','macgen',ADDON_ICON,ADDON_FANART,'', isFolder=True)
    CreateDir('[COLOR white][B]MAC COMBO UPLOAD/DOWNLOAD[/B][/COLOR]','ur','combo',ADDON_ICON,ADDON_FANART,'')
    CreateDir('[COLOR white][B]LIST VIEWER/DOWNLOAD/UPLOAD[/B][/COLOR]','ur', 'log_tools', ADDON_ICON,ADDON_FANART,'')
    CreateDir('[COLOR white][B]SPEEDTEST[/B][/COLOR]','ur', 'speedtest', ADDON_ICON,ADDON_FANART,'')
    CreateDir('[COLOR white][B]ADVANCED SETTINGS (BUFFER SIZE)[/B][/COLOR]','ur', 'adv_settings', ADDON_ICON,ADDON_FANART,'')
    CreateDir('[COLOR white][B]MAINTENANCE[/B][/COLOR]','ur', 'maintenance', ADDON_ICON,ADDON_FANART,'', isFolder=True)
    CreateDir('[COLOR white][B]BACKUP/RESTORE[/B][/COLOR]','ur','backup_restore',ADDON_ICON,ADDON_FANART,'')
    CreateDir('[COLOR white][B]SETTINGS[/B][/COLOR]','ur','settings',ADDON_ICON,ADDON_FANART,'')

def CAT1_TOOLS():  
     import macgen
     return CATEGORIES()
    

def MAINTENANCE():
    nextAutoCleanup = maintenance.getNextMaintenance()
    if nextAutoCleanup > 0:
        nextAutoCleanup = time.strftime("%a, %d %b %Y %I:%M:%S %p %Z", time.localtime(nextAutoCleanup))
        CreateDir('Next Auto Cleanup: %s' % nextAutoCleanup,'xxx','xxx',None,ADDON_FANART,'',isFolder=False,iconImage='DefaultIconInfo.png')
    CreateDir('Clear Cache','url','clear_cache',ADDON_ICON,ADDON_FANART,'')
    CreateDir('Clear Packages','url','clear_packages',ADDON_ICON,ADDON_FANART,'')
    CreateDir('Clear Thumbnails','url','clear_thumbs',ADDON_ICON,ADDON_FANART,'')


# ###########################################################################################
# ###########################################################################################



def OPEN_URL(url):
    r = requests.get(url).content
    return r
def REMOVE_EMPTY_FOLDERS():
#initialize the counters
    print('########### Start Removing Empty Folders #########')
    empty_count = 0
    used_count = 0
    for curdir, subdirs, files in os.walk(HOME):
        try:
            if len(subdirs) == 0 and len(files) == 0: #check for empty directories. len(files) == 0 may be overkill
                empty_count += 1 #increment empty_count
                os.rmdir(curdir) #delete the directory
                print('successfully removed: ' + curdir)
            elif len(subdirs) > 0 and len(files) > 0: #check for used directories
                used_count += 1 #increment used_count
        except:pass

def CreateDir(name, url, action, icon, fanart, description, isFolder=False, iconImage="DefaultFolder.png"):
        if icon == None or icon == '': icon = ADDON_ICON
        u=sys.argv[0]+"?url="+quote_plus(url)+"&action="+str(action)+"&name="+quote_plus(name)+"&icon="+quote_plus(icon)+"&fanart="+quote_plus(fanart)+"&description="+quote_plus(description)
        ok=True
        if PY2:
            liz=xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=icon)
        else:
            liz=xbmcgui.ListItem(name)
            liz.setArt({'icon': iconImage})
            liz.setArt({'thumbnailImage': icon})
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
        return ok


if PY2:
    from urlparse import parse_qsl
else:
    from urllib.parse import parse_qsl

params = dict(parse_qsl(sys.argv[2].replace('?','')))
action = params.get('action')

icon = params.get('icon')

name = params.get('name')

title = params.get('title')

year = params.get('year')

fanart = params.get('fanart')

tvdb = params.get('tvdb')

tmdb = params.get('tmdb')

season = params.get('season')

episode = params.get('episode')

tvshowtitle = params.get('tvshowtitle')

premiered = params.get('premiered')

url = params.get('url')

image = params.get('image')

meta = params.get('meta')

select = params.get('select')

query = params.get('query')

description = params.get('description')

content = params.get('content')

if action   == None: CATEGORIES()
elif action == 'settings': control.openSettings()
elif action == 'scan_on':
    # Obriši stopflag (ako ga je neko ostavio)
    if xbmcvfs.exists(STOPFLAG_PATH):
        xbmcvfs.delete(STOPFLAG_PATH)

    # Sada pokrećemo scan.py
    xbmc.executebuiltin('RunScript("special://home/addons/script.linxscanner/scan.py")')
elif action == 'scan_off':
    # Kreiramo .stopflag
    stop_path = translatePath(os.path.join('special://home/addons/script.linxscanner', 'stopflag.txt'))
    # Ispišite putanju u log
    xbmc.log(f"Creating stopflag at: {stop_path}", level=xbmc.LOGINFO)

    try:
        # standardni Python open
        with open(stop_path, 'w') as f:
            f.write('stop now')
        
        # Po želji - mala obavijest
        dialog.notification(
            "Scan", 
            f"Stopflag created at: {stop_path}", 
            xbmcgui.NOTIFICATION_INFO, 
            3000
        )
    except Exception as e:
        dialog.ok("Error", f"Failed to create stopflag:\n{e}")
elif action == 'combo':
    xbmc.executebuiltin('Runscript("special://home/addons/script.linxscanner/resources/lib/modules/combo.py")') 
elif action == 'macgen': CAT1_TOOLS()

elif action == 'maintenance': MAINTENANCE()

    
elif action == 'adv_settings':
    from resources.lib.modules import tools
    tools.advancedSettings()

elif action == 'clear_cache':
    from resources.lib.modules import maintenance
    maintenance.clearCache()

elif action == 'log_tools':
    from resources.lib.modules import logviewer
    logviewer.logView()


elif action == 'clear_packages':
    from resources.lib.modules import maintenance
    maintenance.purgePackages()
elif action == 'clear_thumbs':
    from resources.lib.modules import maintenance
    maintenance.deleteThumbnails()

elif action == 'backup_restore':
    from resources.lib.modules import wiz
    typeOfBackup = ['BACKUP', 'RESTORE']
    s_type = control.selectDialog(typeOfBackup)
    if s_type == 0:
        modes = ['Full Backup', 'Addons Settings']
        select = control.selectDialog(modes)
        if select == 0: wiz.backup(mode='full')
        elif select == 1: wiz.backup(mode='userdata')
    elif s_type == 1: wiz.restoreFolder()

elif action == 'install_build':
    from resources.lib.modules import wiz
    wiz.skinswap()
    yesDialog = dialog.yesno(AddonTitle, 'Do you want to perform a Fresh Start before Installing your Build?', yeslabel='Yes', nolabel='No')
    if yesDialog: FRESHSTART(mode='silent')

    wiz.buildInstaller(url)

elif action == 'speedtest':
    xbmc.executebuiltin('Runscript("special://home/addons/script.linxscanner/resources/lib/modules/speedtest.py")')

xbmcplugin.endOfDirectory(int(sys.argv[1]))

