'''#####-----Build File-----#####'''
buildfile = 'https://github.com/addoncod/balkanlink/raw/refs/heads/main/builds.json'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://CHANGEME'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
